import { render, screen, fireEvent } from '@testing-library/react'
import Modal from '../Modal/Modal'
import styles from '../Modal/Modal.module.scss'

describe('Modal', () => {
  const onClose = jest.fn()

  beforeEach(() => {
    onClose.mockClear()
  })

  it('não renderiza quando isOpen é false', () => {
    const { container } = render(
      <Modal isOpen={false} onClose={onClose}>
        <p>Conteúdo</p>
      </Modal>
    )
    expect(container.firstChild).toBeNull()
  })

  it('renderiza quando isOpen é true', () => {
    render(
      <Modal isOpen={true} onClose={onClose} title="Título do Modal">
        <p>Conteúdo</p>
      </Modal>
    )
    expect(screen.getByText('Título do Modal')).toBeInTheDocument()
    expect(screen.getByText('Conteúdo')).toBeInTheDocument()
  })

  it('chama onClose ao clicar no botão de fechar', () => {
    render(
      <Modal isOpen={true} onClose={onClose}>
        <p>Conteúdo</p>
      </Modal>
    )
    const closeBtn = screen.getByLabelText('Fechar')
    fireEvent.click(closeBtn)
    expect(onClose).toHaveBeenCalledTimes(1)
  })

  it('chama onClose ao clicar no backdrop', () => {
    const { container } = render(
      <Modal isOpen={true} onClose={onClose}>
        <p>Conteúdo</p>
      </Modal>
    )
    const backdrop = container.querySelector(`.${styles.backdrop}`)
    fireEvent.click(backdrop!)
    expect(onClose).toHaveBeenCalledTimes(1)
  })

  it('não chama onClose ao clicar dentro do modal', () => {
    const { container } = render(
      <Modal isOpen={true} onClose={onClose}>
        <p>Conteúdo</p>
      </Modal>
    )
    const modal = container.querySelector(`.${styles.modal}`)
    fireEvent.click(modal!)
    expect(onClose).not.toHaveBeenCalled()
  })

  it('chama onClose ao pressionar Escape', () => {
    render(
      <Modal isOpen={true} onClose={onClose}>
        <p>Conteúdo</p>
      </Modal>
    )
    fireEvent.keyDown(window, { key: 'Escape' })
    expect(onClose).toHaveBeenCalledTimes(1)
  })
})
