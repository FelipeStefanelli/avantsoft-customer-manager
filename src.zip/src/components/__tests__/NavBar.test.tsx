import { render, screen, fireEvent } from '@testing-library/react'
import { MemoryRouter } from 'react-router-dom'
import NavBar from '../NavBar/NavBar'
import { useAuth } from '../../hooks/useAuth'

jest.mock('../../hooks/useAuth', () => ({
  useAuth: jest.fn()
}))

describe('NavBar', () => {
  const logoutMock = jest.fn()

  beforeEach(() => {
    (useAuth as jest.Mock).mockReturnValue({ logout: logoutMock })
    logoutMock.mockClear()
  })

  const renderComponent = () =>
    render(
      <MemoryRouter>
        <NavBar />
      </MemoryRouter>
    )

  it('renderiza os links de navegação', () => {
    renderComponent()
    expect(screen.getAllByText(/Clientes/i).length).toBeGreaterThan(0)
    expect(screen.getAllByText(/Estatísticas/i).length).toBeGreaterThan(0)
    expect(screen.getAllByText(/Sair/i).length).toBeGreaterThan(0)
  })

  it('chama logout ao clicar no botão "Sair"', () => {
    renderComponent()
    const logoutBtn = screen.getAllByText('Sair')[0]
    fireEvent.click(logoutBtn)
    expect(logoutMock).toHaveBeenCalledTimes(1)
  })

  it('abre e fecha o menu mobile corretamente', () => {
    renderComponent()

    const toggleBtn = screen.getByLabelText('Abrir menu')
    fireEvent.click(toggleBtn)
    expect(screen.getByLabelText('Fechar menu')).toBeInTheDocument()

    fireEvent.click(screen.getByLabelText('Fechar menu'))
    expect(screen.getByLabelText('Abrir menu')).toBeInTheDocument()
  })

  it('fecha o menu mobile ao clicar em um link', () => {
    renderComponent()

    const toggleBtn = screen.getByLabelText('Abrir menu')
    fireEvent.click(toggleBtn)

    const clienteLinkMobile = screen.getAllByText('Clientes')[1]
    fireEvent.click(clienteLinkMobile)

    expect(screen.getByLabelText('Abrir menu')).toBeInTheDocument()
  })

  it('chama logout e fecha o menu ao clicar no botão "Sair" do menu mobile', () => {
    renderComponent()

    const toggleBtn = screen.getByLabelText('Abrir menu')
    fireEvent.click(toggleBtn)

    const logoutBtnMobile = screen.getAllByText('Sair')[1]
    fireEvent.click(logoutBtnMobile)

    expect(logoutMock).toHaveBeenCalledTimes(1)
    expect(screen.getByLabelText('Abrir menu')).toBeInTheDocument()
  })
})
