import { render, screen, fireEvent } from '@testing-library/react';
import Button from '../Button/Button';
import { FiUser } from 'react-icons/fi';

describe('Button', () => {
  it('renderiza com o texto fornecido', () => {
    render(<Button>Enviar</Button>);
    expect(screen.getByRole('button', { name: /enviar/i })).toBeInTheDocument();
  });

  it('chama a função onClick quando clicado', () => {
    const handleClick = jest.fn();
    render(<Button onClick={handleClick}>Clique</Button>);
    fireEvent.click(screen.getByText('Clique'));
    expect(handleClick).toHaveBeenCalledTimes(1);
  });

  it('renderiza com o ícone', () => {
    render(<Button icon={<FiUser />}>Perfil</Button>);
    expect(screen.getByRole('button')).toContainElement(screen.getByText('Perfil'));
    expect(screen.getByTestId('button-icon')).toBeInTheDocument();
  });

  it('aplica as classes corretas para variantes e tamanhos', () => {
    const { container } = render(<Button variant='danger' size='large'>Excluir</Button>);
    const button = container.querySelector('button');
    expect(button?.className).toMatch(/danger/);
    expect(button?.className).toMatch(/large/);
  });

  it('pode ser desabilitado', () => {
    render(<Button disabled>Desabilitado</Button>);
    expect(screen.getByRole('button')).toBeDisabled();
  });
});
