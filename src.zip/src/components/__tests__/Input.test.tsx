import { render, screen, fireEvent } from '@testing-library/react'
import Input from '../Input/Input'
import { FiMail } from 'react-icons/fi'

describe('Input', () => {
  it('renderiza com o placeholder', () => {
    render(<Input placeholder='Digite seu e-mail' />)
    expect(screen.getByPlaceholderText('Digite seu e-mail')).toBeInTheDocument()
  })

  it('renderiza com o label', () => {
    render(<Input id="Email" label='Email' />)
    expect(screen.getByLabelText('Email')).toBeInTheDocument()
  })

  it('chama onChange quando digitado', () => {
    const handleChange = jest.fn()
    render(<Input placeholder='Digite aqui' onChange={handleChange} />)
    const input = screen.getByPlaceholderText('Digite aqui')
    fireEvent.change(input, { target: { value: 'teste' } })
    expect(handleChange).toHaveBeenCalledTimes(1)
  })

  it('renderiza com o ícone', () => {
    render(<Input icon={<FiMail />} placeholder='Com ícone' />)
    expect(screen.getByTestId('input-icon')).toBeInTheDocument()
  })

  it('aplica classes corretamente', () => {
    const { container } = render(<Input className='meu-estilo' placeholder='Classe extra' />)
    const input = container.querySelector('input')
    expect(input?.className).toMatch(/meu-estilo/)
  })
})
